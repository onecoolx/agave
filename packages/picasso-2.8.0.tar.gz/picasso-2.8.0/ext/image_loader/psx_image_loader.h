/* Picasso - a vector graphics library
 *
 * Copyright (C) 2016 Zhang Ji Peng
 * Contact: onecoolx@gmail.com
 */

#ifndef _PSX_IMAGE_LOADER_H_
#define _PSX_IMAGE_LOADER_H_

#include "psx_image_modules.h"

struct image_modules_mgr* _get_modules(void);

#endif /*_PSX_IMAGE_LOADER_H_*/

